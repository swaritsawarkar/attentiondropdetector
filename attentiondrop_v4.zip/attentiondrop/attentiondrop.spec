# -*- mode: python ; coding: utf-8 -*-
# Build with: python -m PyInstaller attentiondrop.spec

block_cipher = None

a = Analysis(
    ['app.py'],
    pathex=['.'],
    binaries=[],
    datas=[
        ('templates', 'templates'),
        ('static', 'static'),
        ('analyzer.py', '.'),
        ('visualizer.py', '.'),
        ('highlights.py', '.'),
    ],
    hiddenimports=[
        'flask',
        'flask.templating',
        'jinja2',
        'werkzeug',
        'werkzeug.serving',
        'cv2',
        'numpy',
        'librosa',
        'librosa.core',
        'librosa.feature',
        'librosa.effects',
        'soundfile',
        'audioread',
        'sklearn',
        'sklearn.utils',
        'numba',
        'llvmlite',
        'matplotlib',
        'matplotlib.backends.backend_agg',
        'scipy',
        'scipy.signal',
        # MediaPipe — import submodules directly so PyInstaller picks them up
        'mediapipe',
        'mediapipe.python',
        'mediapipe.python.solutions',
        'mediapipe.python.solutions.face_detection',
        'mediapipe.python._framework_bindings',
        'mediapipe.tasks',
        'mediapipe.tasks.python',
        # PySceneDetect
        'scenedetect',
        'scenedetect.detectors',
        'scenedetect.detectors.content_detector',
    ],
    hookspath=[],
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='AttentionDropDetector',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)
