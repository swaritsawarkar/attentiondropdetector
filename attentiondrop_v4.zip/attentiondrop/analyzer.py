"""
Attention Drop Detector — Analyzer
====================================
Upgraded signal extraction pipeline:
  - Face detection   : MediaPipe (replaces Haar Cascade)
  - Motion           : Optical Flow / Farneback (replaces raw frame diff)
  - Audio            : Librosa spectral + speech energy (replaces raw RMS)
  - Scene cuts       : PySceneDetect ContentDetector (replaces manual threshold)

Usage:
  python analyzer.py myvideo.mp4
  python analyzer.py myvideo.mp4 --window 5 --mode facecam --out results.json
"""

import argparse
import json
import os
import sys
import warnings
from dataclasses import asdict, dataclass, field
from typing import Optional

warnings.filterwarnings("ignore")

import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

try:
    import librosa
    import librosa.feature
except ImportError:
    librosa = None

try:
    import mediapipe as mp
    # Import the submodule directly — mp.solutions fails when packaged with PyInstaller
    from mediapipe.python.solutions import face_detection as _mp_face_module
    _mp_face = _mp_face_module
    HAS_MEDIAPIPE = True
except (ImportError, AttributeError):
    HAS_MEDIAPIPE = False

try:
    from scenedetect import open_video, SceneManager
    from scenedetect.detectors import ContentDetector
    HAS_SCENEDETECT = True
except ImportError:
    HAS_SCENEDETECT = False


# ── Content Mode Presets ──────────────────────────────────────────────────────

MODES = {
    "default": {
        "label":          "Default",
        "weight_motion":  0.40,
        "weight_cuts":    0.25,
        "weight_audio":   0.25,
        "weight_face":    0.10,
        "score_drop":     0.35,
        "score_engaging": 0.65,
        "low_motion":     0.15,
        "low_audio":      0.10,
        "static_secs":    8.0,
    },
    "facecam": {
        "label":          "Face / Talking Head",
        "weight_motion":  0.10,
        "weight_cuts":    0.05,
        "weight_audio":   0.50,
        "weight_face":    0.35,
        "score_drop":     0.25,
        "score_engaging": 0.55,
        "low_motion":     0.03,
        "low_audio":      0.08,
        "static_secs":    30.0,
    },
    "podcast": {
        "label":          "Podcast / Interview",
        "weight_motion":  0.05,
        "weight_cuts":    0.05,
        "weight_audio":   0.65,
        "weight_face":    0.25,
        "score_drop":     0.20,
        "score_engaging": 0.50,
        "low_motion":     0.02,
        "low_audio":      0.12,
        "static_secs":    60.0,
    },
    "gaming": {
        "label":          "Gaming",
        "weight_motion":  0.45,
        "weight_cuts":    0.10,
        "weight_audio":   0.35,
        "weight_face":    0.10,
        "score_drop":     0.30,
        "score_engaging": 0.60,
        "low_motion":     0.20,
        "low_audio":      0.10,
        "static_secs":    15.0,
    },
    "vlog": {
        "label":          "Vlog / Lifestyle",
        "weight_motion":  0.25,
        "weight_cuts":    0.20,
        "weight_audio":   0.35,
        "weight_face":    0.20,
        "score_drop":     0.28,
        "score_engaging": 0.58,
        "low_motion":     0.08,
        "low_audio":      0.08,
        "static_secs":    12.0,
    },
    "tutorial": {
        "label":          "Tutorial / Screenshare",
        "weight_motion":  0.15,
        "weight_cuts":    0.20,
        "weight_audio":   0.55,
        "weight_face":    0.10,
        "score_drop":     0.22,
        "score_engaging": 0.52,
        "low_motion":     0.02,
        "low_audio":      0.10,
        "static_secs":    20.0,
    },
    "shortform": {
        "label":          "Short-form / Reels / TikTok",
        "weight_motion":  0.35,
        "weight_cuts":    0.35,
        "weight_audio":   0.20,
        "weight_face":    0.10,
        "score_drop":     0.40,
        "score_engaging": 0.70,
        "low_motion":     0.20,
        "low_audio":      0.08,
        "static_secs":    4.0,
    },
    "cinematic": {
        "label":          "Cinematic / Film / Essay",
        "weight_motion":  0.15,
        "weight_cuts":    0.10,
        "weight_audio":   0.55,
        "weight_face":    0.20,
        "score_drop":     0.18,
        "score_engaging": 0.48,
        "low_motion":     0.02,
        "low_audio":      0.08,
        "static_secs":    45.0,
    },
}

DEFAULT_MODE = "default"


# ── Data classes ──────────────────────────────────────────────────────────────

@dataclass
class Window:
    start:       float
    end:         float
    motion:      float
    cuts:        int
    audio:       float
    face:        bool
    face_conf:   float = 0.0   # MediaPipe confidence (0–1)
    speech_prob: float = 0.0   # estimated speech presence (0–1)
    score:       float = 0.0
    label:       str   = "neutral"


@dataclass
class Drop:
    start:       float
    end:         float
    reasons:     list[str] = field(default_factory=list)
    suggestions: list[str] = field(default_factory=list)


@dataclass
class Result:
    video:      str
    duration:   float
    window_sec: float
    mode:       str          = DEFAULT_MODE
    windows:    list[Window] = field(default_factory=list)
    drops:      list[Drop]   = field(default_factory=list)
    summary:    dict         = field(default_factory=dict)


# ── Scene cut detector (PySceneDetect) ────────────────────────────────────────

def detect_cuts_scenedetect(video_path: str) -> list[float]:
    """
    Returns a sorted list of timestamps (in seconds) where scene cuts occur.
    Uses PySceneDetect's ContentDetector — purpose-built, far more accurate
    than a raw frame-diff threshold.
    """
    if not HAS_SCENEDETECT:
        return []
    try:
        video     = open_video(video_path)
        manager   = SceneManager()
        manager.add_detector(ContentDetector(threshold=27.0))
        manager.detect_scenes(video, show_progress=False)
        scenes    = manager.get_scene_list()
        # Each scene boundary is the START of a new scene (i.e. a cut happened)
        cuts = [scene[0].get_seconds() for scene in scenes[1:]]
        return cuts
    except Exception as e:
        print(f"  [warn] PySceneDetect failed ({e}) — falling back to frame-diff cuts")
        return []


def assign_cuts_to_windows(cut_times: list[float], windows: list[Window]) -> None:
    """Counts how many cuts fall inside each window."""
    for w in windows:
        w.cuts = sum(1 for t in cut_times if w.start <= t < w.end)


# ── Motion extractor (Optical Flow / Farneback) ───────────────────────────────

class MotionExtractor:
    """
    Uses Farneback dense optical flow to measure actual pixel movement
    rather than raw frame difference. Much more robust to lighting changes,
    compression artifacts, and subtle motion.
    """

    def __init__(self, path: str, window_sec: float):
        if cv2 is None:
            raise ImportError("Install opencv-python")
        self.path       = path
        self.window_sec = window_sec

    def extract(self) -> tuple[list[Window], float]:
        cap = cv2.VideoCapture(self.path)
        if not cap.isOpened():
            raise FileNotFoundError(f"Cannot open video: {self.path}")

        fps          = cap.get(cv2.CAP_PROP_FPS) or 30.0
        total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        duration     = total_frames / fps
        win_frames   = int(self.window_sec * fps)

        windows  = []
        win_idx  = 0

        while True:
            start_sec = win_idx * self.window_sec
            end_sec   = min(start_sec + self.window_sec, duration)
            if start_sec >= duration:
                break

            start_frame = int(start_sec * fps)
            cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

            magnitudes = []
            prev_gray  = None
            # Sample ~15 frames per window for speed
            step = max(1, win_frames // 15)

            for _ in range(0, win_frames, step):
                ret, frame = cap.read()
                if not ret:
                    break
                # Downscale for speed
                small = cv2.resize(frame, (320, 180))
                gray  = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)

                if prev_gray is not None:
                    flow = cv2.calcOpticalFlowFarneback(
                        prev_gray, gray,
                        None,
                        pyr_scale=0.5, levels=3, winsize=15,
                        iterations=3, poly_n=5, poly_sigma=1.2,
                        flags=0,
                    )
                    # Magnitude of flow vectors
                    mag, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
                    magnitudes.append(float(np.mean(mag)))

                prev_gray = gray

            # Normalize: typical talking-head has ~0.5–2.0 px/frame flow
            # fast action can hit 10+. We normalise to 0–1 with a soft cap at 8.
            raw    = float(np.mean(magnitudes)) if magnitudes else 0.0
            motion = float(np.clip(raw / 8.0, 0.0, 1.0))

            windows.append(Window(
                start  = round(start_sec, 2),
                end    = round(end_sec,   2),
                motion = round(motion,    4),
                cuts   = 0,
                audio  = 0.0,
                face   = False,
            ))
            win_idx += 1

        cap.release()
        return windows, duration


# ── Audio extractor (Librosa spectral) ───────────────────────────────────────

class AudioExtractor:
    """
    Replaces raw RMS with a richer audio signal:
      - Spectral energy (weighted RMS emphasising speech frequencies 300–3400 Hz)
      - Speech probability approximated from zero-crossing rate + spectral centroid
    This distinguishes silence / music / speech much better than raw RMS.
    """

    def __init__(self, path: str):
        self.path = path

    def enrich(self, windows: list[Window]) -> None:
        if librosa is None:
            print("  [warn] librosa not installed — audio skipped")
            return
        try:
            y, sr = librosa.load(self.path, sr=22050, mono=True)
        except Exception as e:
            print(f"  [warn] Audio load failed ({e})")
            return

        hop = 512

        # ── Spectral energy focused on speech band (300–3400 Hz) ──────────────
        stft      = np.abs(librosa.stft(y, hop_length=hop))
        freqs     = librosa.fft_frequencies(sr=sr)
        speech_mask = (freqs >= 300) & (freqs <= 3400)
        speech_stft = stft[speech_mask, :]
        energy      = np.mean(speech_stft ** 2, axis=0)  # per-frame energy
        energy_norm = energy / (energy.max() + 1e-9)

        # ── Speech probability proxy ───────────────────────────────────────────
        zcr       = librosa.feature.zero_crossing_rate(y, hop_length=hop)[0]
        centroid  = librosa.feature.spectral_centroid(y=y, sr=sr, hop_length=hop)[0]
        # Speech: ZCR between 0.02–0.25, centroid 500–3000 Hz
        zcr_norm  = np.clip(zcr / 0.25, 0, 1)
        cent_norm = np.clip(centroid / 3000.0, 0, 1)
        speech_p  = (zcr_norm * 0.4 + cent_norm * 0.6)

        frame_times = librosa.frames_to_time(np.arange(len(energy_norm)), sr=sr, hop_length=hop)

        for w in windows:
            mask = (frame_times >= w.start) & (frame_times < w.end)
            if mask.any():
                w.audio       = round(float(energy_norm[mask].mean()), 4)
                w.speech_prob = round(float(speech_p[mask].mean()), 4)
            else:
                w.audio       = 0.0
                w.speech_prob = 0.0


# ── Face detector (MediaPipe) ─────────────────────────────────────────────────

class FaceExtractor:
    """
    Uses MediaPipe Face Detection — detects faces at any angle, distance,
    and under varied lighting. Scores confidence per detection (0–1).
    Falls back to OpenCV Haar Cascade if MediaPipe is not installed.
    """

    def __init__(self, path: str, window_sec: float):
        self.path       = path
        self.window_sec = window_sec

    def enrich(self, windows: list[Window]) -> None:
        if HAS_MEDIAPIPE:
            self._enrich_mediapipe(windows)
        else:
            print("  [warn] MediaPipe not installed — using Haar Cascade (less accurate)")
            print("         Install with: pip install mediapipe")
            self._enrich_haar(windows)

    def _enrich_mediapipe(self, windows: list[Window]) -> None:
        if cv2 is None:
            return

        cap = cv2.VideoCapture(self.path)
        if not cap.isOpened():
            return

        fps        = cap.get(cv2.CAP_PROP_FPS) or 30.0
        win_frames = int(self.window_sec * fps)

        with _mp_face.FaceDetection(
            model_selection=1,        # 1 = full-range model (better for varied distances)
            min_detection_confidence=0.4,   # lower = catches more faces, more false positives
        ) as detector:

            for w in windows:
                start_frame = int(w.start * fps)
                cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)

                confidences = []
                step = max(1, win_frames // 8)  # sample 8 frames per window

                for _ in range(0, win_frames, step):
                    ret, frame = cap.read()
                    if not ret:
                        break
                    # MediaPipe requires RGB
                    rgb     = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                    results = detector.process(rgb)
                    if results.detections:
                        for det in results.detections:
                            confidences.append(det.score[0])

                if confidences:
                    w.face      = True
                    w.face_conf = round(float(np.mean(confidences)), 4)
                else:
                    w.face      = False
                    w.face_conf = 0.0

        cap.release()

    def _enrich_haar(self, windows: list[Window]) -> None:
        if cv2 is None:
            return
        xml = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        if not os.path.exists(xml):
            return
        face_det = cv2.CascadeClassifier(xml)
        cap      = cv2.VideoCapture(self.path)
        if not cap.isOpened():
            return

        fps        = cap.get(cv2.CAP_PROP_FPS) or 30.0
        win_frames = int(self.window_sec * fps)

        for w in windows:
            start_frame = int(w.start * fps)
            cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
            step  = max(1, win_frames // 8)
            found = 0

            for _ in range(0, win_frames, step):
                ret, frame = cap.read()
                if not ret:
                    break
                gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = face_det.detectMultiScale(gray, 1.1, 4, minSize=(30, 30))
                if len(faces) > 0:
                    found += 1

            w.face      = found > 0
            w.face_conf = round(found / max(win_frames // step, 1), 4)

        cap.release()


# ── Attention scoring ─────────────────────────────────────────────────────────

class Scorer:
    def __init__(self, mode: str = DEFAULT_MODE):
        cfg           = MODES.get(mode, MODES[DEFAULT_MODE])
        self.wm       = cfg["weight_motion"]
        self.wc       = cfg["weight_cuts"]
        self.wa       = cfg["weight_audio"]
        self.wf       = cfg["weight_face"]
        self.drop     = cfg["score_drop"]
        self.engaging = cfg["score_engaging"]

    def score(self, windows: list[Window]) -> None:
        max_cuts = max((w.cuts for w in windows), default=1) or 1
        for w in windows:
            cut_norm = min(w.cuts / max_cuts, 1.0)
            # Use face_conf (0–1) instead of binary face presence
            face_val = w.face_conf if w.face else 0.0
            # Blend raw audio energy with speech probability
            audio_val = w.audio * 0.6 + w.speech_prob * 0.4

            s = (
                self.wm * w.motion   +
                self.wc * cut_norm   +
                self.wa * audio_val  +
                self.wf * face_val
            )
            w.score = round(min(float(s), 1.0), 4)
            w.label = (
                "drop"     if w.score < self.drop     else
                "engaging" if w.score >= self.engaging else
                "neutral"
            )


# ── Drop explanation ──────────────────────────────────────────────────────────

class Explainer:
    def __init__(self, mode: str = DEFAULT_MODE):
        cfg              = MODES.get(mode, MODES[DEFAULT_MODE])
        self.low_motion  = cfg["low_motion"]
        self.low_audio   = cfg["low_audio"]
        self.static_secs = cfg["static_secs"]
        self.mode        = mode

    def explain(self, windows: list[Window], window_sec: float) -> list[Drop]:
        drops = []
        for i, w in enumerate(windows):
            if w.label != "drop":
                continue

            reasons, suggestions = [], []

            # Motion
            if w.motion < self.low_motion:
                reasons.append(f"Very low motion ({w.motion:.2f}) — screen appears static")
                if self.mode in ("facecam", "podcast", "cinematic"):
                    suggestions.append("Try gesturing more or shifting position slightly")
                else:
                    suggestions.append("Add a zoom, pan, or B-roll cut to break static shots")

            # Pacing / cuts
            if w.cuts == 0:
                dry = 0.0
                for j in range(i, -1, -1):
                    if windows[j].cuts == 0:
                        dry += window_sec
                    else:
                        break
                if dry >= self.static_secs:
                    reasons.append(f"No scene cuts for ~{dry:.0f}s — pacing too slow")
                    if self.mode == "shortform":
                        suggestions.append("Add a cut every 2–3 seconds for short-form pacing")
                    elif self.mode in ("facecam", "podcast"):
                        suggestions.append("Consider a jump cut or B-roll overlay to break the shot")
                    else:
                        suggestions.append("Insert a cut or reaction clip every 4–6 seconds")

            # Audio / speech
            if w.audio < self.low_audio and w.speech_prob < 0.25:
                reasons.append(f"Audio energy very low ({w.audio:.2f}) and no speech detected")
                if self.mode == "podcast":
                    suggestions.append("Dead air in podcasts kills retention — check mic or fill silence")
                elif self.mode == "gaming":
                    suggestions.append("Keep commentary going — silence during gaming loses viewers fast")
                else:
                    suggestions.append("Add background music, voice presence, or sound effects")
            elif w.audio < self.low_audio:
                reasons.append(f"Audio energy low ({w.audio:.2f}) — content sounds quiet")
                suggestions.append("Raise your voice level or add music under the section")

            # Face / human presence
            if not w.face:
                if self.mode in ("facecam", "podcast", "vlog"):
                    reasons.append("No face detected — human connection is lost")
                    suggestions.append("Make sure your face is clearly visible and well-lit")
                elif self.mode not in ("tutorial", "gaming", "cinematic"):
                    if w.audio < 0.30:
                        reasons.append("No face and low audio — very low human connection")
                        suggestions.append("Show your face or add text overlays to maintain presence")
            elif w.face_conf < 0.5:
                reasons.append(f"Face detected but confidence low ({w.face_conf:.0%}) — may be partially obscured")
                suggestions.append("Face the camera more directly and improve lighting on your face")

            if not reasons:
                reasons.append(f"All signals weak (score {w.score:.2f}) — general energy loss")
                suggestions.append("Review pacing — add cuts, music, or motion to lift energy")

            drops.append(Drop(
                start       = w.start,
                end         = w.end,
                reasons     = reasons,
                suggestions = suggestions,
            ))

        return drops


# ── Summary ───────────────────────────────────────────────────────────────────

def make_summary(windows: list[Window], drops: list[Drop]) -> dict:
    scores = [w.score for w in windows]
    return {
        "total_windows":  len(windows),
        "drop_count":     len(drops),
        "engaging_count": sum(1 for w in windows if w.label == "engaging"),
        "neutral_count":  sum(1 for w in windows if w.label == "neutral"),
        "avg_score":      round(float(np.mean(scores)), 4)  if scores else 0.0,
        "min_score":      round(float(np.min(scores)), 4)   if scores else 0.0,
        "max_score":      round(float(np.max(scores)), 4)   if scores else 0.0,
        "avg_motion":     round(float(np.mean([w.motion for w in windows])), 4),
        "avg_audio":      round(float(np.mean([w.audio  for w in windows])), 4),
        "avg_face_conf":  round(float(np.mean([w.face_conf for w in windows])), 4),
        "total_cuts":     sum(w.cuts for w in windows),
        "face_pct":       round(sum(1 for w in windows if w.face) / max(len(windows), 1), 4),
        "drop_time_pct":  round(len(drops) / max(len(windows), 1), 4),
    }


# ── Main pipeline ─────────────────────────────────────────────────────────────

def analyze(
    video_path: str,
    window_sec: float         = 5.0,
    mode:       str           = DEFAULT_MODE,
    out_json:   Optional[str] = None,
    verbose:    bool          = True,
) -> Result:

    def log(msg):
        if verbose:
            print(msg)

    log(f"\n  Video : {video_path}")
    log(f"  Window: {window_sec}s  |  Mode: {MODES.get(mode, MODES[DEFAULT_MODE])['label']}")
    log(f"  MediaPipe  : {'YES' if HAS_MEDIAPIPE else 'NO — install: pip install mediapipe'}")
    log(f"  SceneDetect: {'YES' if HAS_SCENEDETECT else 'NO — install: pip install scenedetect'}\n")

    log("[1/6] Extracting motion with Optical Flow (Farneback)...")
    motion_ex = MotionExtractor(video_path, window_sec)
    windows, duration = motion_ex.extract()
    log(f"       {len(windows)} windows · {duration:.1f}s total")

    log("[2/6] Detecting scene cuts with PySceneDetect...")
    if HAS_SCENEDETECT:
        cut_times = detect_cuts_scenedetect(video_path)
        assign_cuts_to_windows(cut_times, windows)
        log(f"       {len(cut_times)} cuts detected")
    else:
        log("       SceneDetect not available — cuts set to 0")

    log("[3/6] Extracting audio (spectral speech energy)...")
    AudioExtractor(video_path).enrich(windows)

    log("[4/6] Detecting faces with MediaPipe...")
    FaceExtractor(video_path, window_sec).enrich(windows)
    face_count = sum(1 for w in windows if w.face)
    log(f"       Face detected in {face_count}/{len(windows)} windows")

    log("[5/6] Scoring attention...")
    Scorer(mode).score(windows)

    log("[6/6] Explaining drops...")
    drops   = Explainer(mode).explain(windows, window_sec)
    summary = make_summary(windows, drops)

    result = Result(
        video      = video_path,
        duration   = round(duration, 2),
        window_sec = window_sec,
        mode       = mode,
        windows    = windows,
        drops      = drops,
        summary    = summary,
    )

    if out_json:
        with open(out_json, "w") as f:
            json.dump(asdict(result), f, indent=2)
        log(f"  Saved: {out_json}")

    return result


# ── CLI ───────────────────────────────────────────────────────────────────────

def _print_result(result: Result) -> None:
    s = result.summary
    print("\n── Summary " + "─" * 46)
    print(f"  Duration        : {result.duration:.1f}s")
    print(f"  Mode            : {MODES.get(result.mode, {}).get('label', result.mode)}")
    print(f"  Windows         : {s['total_windows']}")
    print(f"  Avg score       : {s['avg_score']:.0%}")
    print(f"  Engaging windows: {s['engaging_count']}")
    print(f"  Neutral windows : {s['neutral_count']}")
    print(f"  Drop windows    : {s['drop_count']}  ({s['drop_time_pct']:.0%} of video)")
    print(f"  Total cuts      : {s['total_cuts']}")
    print(f"  Avg face conf   : {s['avg_face_conf']:.0%}")

    print(f"\n── Drop Zones ({len(result.drops)}) " + "─" * 38)
    for d in result.drops:
        print(f"\n  {d.start:.1f}s – {d.end:.1f}s")
        for r in d.reasons:
            print(f"    WHY  {r}")
        for sg in d.suggestions:
            print(f"    FIX  {sg}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Attention Drop Detector")
    parser.add_argument("video")
    parser.add_argument("--window", "-w", type=float,  default=5.0)
    parser.add_argument("--mode",   "-m", default=DEFAULT_MODE, choices=list(MODES.keys()))
    parser.add_argument("--out",    "-o", default="result.json")
    parser.add_argument("--chart",  "-c", action="store_true")
    args = parser.parse_args()

    result = analyze(args.video, window_sec=args.window, mode=args.mode, out_json=args.out)
    _print_result(result)

    if args.chart:
        from visualizer import plot
        plot(result, save_path="attention_chart.png", show=True)
