"""
Attention Drop Detector — Web UI Backend
"""

import base64
import json
import os
import sys
import tempfile
import threading
import uuid
from dataclasses import asdict
from pathlib import Path

from flask import Flask, jsonify, render_template, request

BASE_DIR = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, BASE_DIR)

from analyzer import analyze, MODES
from visualizer import plot

app = Flask(
    __name__,
    template_folder=os.path.join(BASE_DIR, "templates"),
    static_folder=os.path.join(BASE_DIR, "static"),
)
app.config["MAX_CONTENT_LENGTH"] = 2 * 1024 * 1024 * 1024

JOBS: dict[str, dict] = {}
JOBS_LOCK = threading.Lock()


def _run_job(job_id: str, video_path: str, window_sec: float, mode: str) -> None:
    def progress(step: int, msg: str):
        with JOBS_LOCK:
            JOBS[job_id]["progress"] = {"step": step, "msg": msg}

    try:
        import analyzer as _an

        progress(1, "Extracting video features…")
        cfg = _an.MODES.get(mode, _an.MODES[_an.DEFAULT_MODE])
        vid = _an.VideoExtractor(video_path, window_sec, cut_thresh=cfg["cut_thresh"])
        windows, duration = vid.extract()

        progress(2, "Extracting audio features…")
        _an.AudioExtractor(video_path).enrich(windows)

        progress(3, "Scoring attention windows…")
        _an.Scorer(mode).score(windows)

        progress(4, "Explaining drop zones…")
        drops = _an.Explainer(mode).explain(windows, window_sec)

        progress(5, "Building summary…")
        summary = _an.make_summary(windows, drops)

        result_obj = _an.Result(
            video=video_path,
            duration=round(duration, 2),
            window_sec=window_sec,
            mode=mode,
            windows=windows,
            drops=drops,
            summary=summary,
        )

        progress(6, "Generating attention chart…")
        chart_path = video_path + "_chart.png"
        plot(result_obj, save_path=chart_path, show=False)

        chart_b64 = ""
        if os.path.exists(chart_path):
            with open(chart_path, "rb") as f:
                chart_b64 = base64.b64encode(f.read()).decode()
            os.remove(chart_path)

        with JOBS_LOCK:
            JOBS[job_id]["status"]   = "done"
            JOBS[job_id]["result"]   = asdict(result_obj)
            JOBS[job_id]["chart_b64"] = chart_b64
            JOBS[job_id]["progress"] = {"step": 6, "msg": "Done"}

    except Exception as e:
        with JOBS_LOCK:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"]  = str(e)
    finally:
        try:
            os.remove(video_path)
        except Exception:
            pass


@app.route("/")
def index():
    return render_template("index.html", modes=MODES)


@app.route("/analyze", methods=["POST"])
def start_analysis():
    if "video" not in request.files:
        return jsonify({"error": "No video file"}), 400

    file       = request.files["video"]
    window_sec = float(request.form.get("window", 5.0))
    mode       = request.form.get("mode", "default")
    if mode not in MODES:
        mode = "default"

    suffix = Path(file.filename).suffix or ".mp4"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    file.save(tmp.name)
    tmp.close()

    job_id = str(uuid.uuid4())
    with JOBS_LOCK:
        JOBS[job_id] = {
            "status":   "running",
            "progress": {"step": 0, "msg": "Starting…"},
            "result":   None,
            "chart_b64": "",
            "error":    None,
        }

    t = threading.Thread(
        target=_run_job,
        args=(job_id, tmp.name, window_sec, mode),
        daemon=True,
    )
    t.start()
    return jsonify({"job_id": job_id})


@app.route("/status/<job_id>")
def job_status(job_id):
    with JOBS_LOCK:
        job = JOBS.get(job_id)
    if not job:
        return jsonify({"error": "Unknown job"}), 404
    return jsonify(job)


if __name__ == "__main__":
    import webbrowser
    port = 7432
    print(f"Attention Drop Detector running at http://localhost:{port}")
    threading.Timer(1.2, lambda: webbrowser.open(f"http://localhost:{port}")).start()
    app.run(port=port, debug=False, threaded=True)
