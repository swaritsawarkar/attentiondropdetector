# Building the .exe

## Step 1 — Install all dependencies

```
pip install flask pyinstaller opencv-python numpy librosa matplotlib mediapipe scenedetect
```

## Step 2 — Build

From inside the `attentiondrop/` folder:

```
python -m PyInstaller attentiondrop.spec
```

The exe will appear at:
```
dist/AttentionDropDetector.exe
```

Double-click it. It opens your browser automatically at http://localhost:7432.

## What each library does

| Library | Role |
|---|---|
| flask | Web server that runs inside the exe |
| opencv-python | Video reading + Optical Flow motion detection |
| numpy | Numeric processing |
| librosa | Spectral audio + speech energy analysis |
| matplotlib | Chart generation |
| mediapipe | Google's face detection (replaces Haar Cascade) |
| scenedetect | Accurate scene cut detection (replaces manual threshold) |
| pyinstaller | Packages everything into a single .exe |

## Notes

- First launch takes 5–10 seconds (unpacking)
- No Python install needed on the target machine
- To add a custom icon: put a `.ico` file next to `app.py` and set `icon='youricon.ico'` in the spec
